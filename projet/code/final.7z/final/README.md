ELE8704 -  Transmission de données et réseaux internet

Projet de session de 

Ana Manresa Gonzalez, 2223369
Anas Bouhemhem, 1953369
Laure Pourcel, 2164239
Louis Fleurquin-Asselin, 1880414



Le fichier 'code.ipynb' contient le code associé à notre projet de fin de session. 


Afin de faire fonctionner le code il faut modifier les chemins dans le Section 2. Download des données pour pointer vers les fichiers .csv associés à notre collecte des paquets d'un appel en ethernet puis en wifi, du téléchargement d'une vidéo en éthernet puis en wifi et du visionnage d'une vidéo en ethernet puis en wifi, dans cet ordre. 

Le fichier s'exécute sans erreur en une dizaine de minutes. 

Nous avons affiché par défaut les graphiques associés au premier cas, un appel passé en éthernet. Les autres graphiques peuvent être obtenus en modifiant le nom du dataframe associé comme expliaué dans la section 5. 

Le code et rapport associé à ce projet est le fruit du travail de leurs auteurs uniquement. 


